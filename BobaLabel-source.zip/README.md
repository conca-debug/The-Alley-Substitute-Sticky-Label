# Boba Label (starter)

Native Android starter for a Clover Station/Mini label-printing app. The cashier can enter a customer name for the active Clover order from Clover's payment flow. Each cup label will contain the name, drink, and selected non-default customizations/toppings.

## Clover POS modifier names

- Ice: `Regular Ice`, `Less Ice`, `No Ice`.
- Sugar: `Regular Sugar`, `Less Sugar`, `Slight Sugar`, `No Sugar`.
- The POS choices contain no percentages. Regular ice and sugar are omitted from labels; selected non-regular choices print as `Less Ice`, `No Ice`, `Less Sugar`, `Slight Sugar`, or `No Sugar`.
- Omit cup size (the menu says one size, 22 oz).
- Target landscape print size is 2.4 × 1.1 in (62 × 28.9 mm), matching Brother DK-1209 die-cut labels for the QL-810W. The printer connection is USB. Print one image per pre-cut label and set the QL-810W to auto-cut after each printed label (one page per cut). The current code records the DK-1209/USB target, but printing is not wired yet.
- Print every selected optional topping:
  - $0.70: Boba, Passion Fruit Coconut Jelly, Green Tea Jelly, Lychee Coconut Jelly, House-Made Lychee Jelly.
  - $0.95: Brown Sugar Boba, Pudding, Crystal Boba, Snow Velvet.

The POS names, topping lists, and label formatting rules are grouped in `MainActivity.java`. The preview follows the sample label layout: order header, cashier-entered customer name, drink, modifier line, and timestamp. Live Clover order/modifier data is not connected yet, so the app still needs to map each Clover modifier group and selected option to these formatter inputs.

## Current status

The app registers a Clover `MODIFY_ORDER` activity and stores the cashier-entered name against the order ID on-device. It does not yet retrieve live drink/modifier details or print labels. The order broadcast receiver only logs events.

## Next steps

1. Connect Clover `OrderConnector` and map the live menu modifier groups/options to the label rules above.
2. Print one label per drink, including quantity handling and the same order name on each cup (current assumption).
3. Integrate Brother's Android Print SDK with `Channel.newUsbChannel(UsbManager)`, request USB device access, configure DK-1209 media and 2.4 × 1.1 in artwork, and auto-cut after each label; add duplicate protection and reprint controls.
4. Install on a Clover development device and verify real checkout workflows before store deployment.

## Build

Open this folder in Android Studio and allow Gradle sync. Clover's Android SDK is pinned to version 334. Brother's mobile SDK is distributed separately by Brother and has not been bundled here.











