package com.example.bobalabel;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Captures the name for the current Clover order and previews the cup label. */
public final class MainActivity extends Activity {
    private static final String PREFS = "label_names";
    private static final String EXTRA_ORDER_ID = "clover.intent.extra.ORDER_ID";
    private static final String MODIFY_ORDER = "clover.intent.action.MODIFY_ORDER";

    // Print target for Brother QL-810W over USB; actual SDK printing is not wired yet.
    private static final float TARGET_LABEL_WIDTH_IN = 2.4f;
    private static final float TARGET_LABEL_HEIGHT_IN = 1.1f;
    private static final int TARGET_LABEL_WIDTH_MM = 62;
    private static final float TARGET_LABEL_HEIGHT_MM = 28.9f;
    private static final String TARGET_BROTHER_STOCK = "DK-1209";
    private static final String TARGET_BROTHER_SIZE = "DieCutW29H62";
    private static final String TARGET_PRINTER_CONNECTION = "USB";
    private static final boolean TARGET_AUTO_CUT_EACH_LABEL = true;
    private static final int TARGET_LABELS_PER_CUT = 1;

    // Clover POS modifier names and toppings configured from the supplied menu.
    private static final String[] ICE_LEVELS = {"Regular Ice", "Less Ice", "No Ice"};
    private static final String[] SUGAR_LEVELS = {"Regular Sugar", "Less Sugar", "Slight Sugar", "No Sugar"};
    private static final String[] TOPPINGS_070 = {"Boba", "Passion Fruit Coconut Jelly", "Green Tea Jelly", "Lychee Coconut Jelly", "House-Made Lychee Jelly"};
    private static final String[] TOPPINGS_095 = {"Brown Sugar Boba", "Pudding", "Crystal Boba", "Snow Velvet"};

    private String orderId;
    private EditText nameInput;
    private TextView customerNamePreview;

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, float size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private static String sampleModifications() {
        StringBuilder result = new StringBuilder();
        appendIce(result, "No Ice");
        appendSugar(result, "Less Sugar");
        return result.toString();
    }

    private static void appendSugar(StringBuilder label, String value) {
        String v = normalize(value);
        if (v.isEmpty() || v.equals("regular sugar") || v.equals("regular") || v.equals("normal")) return;
        if (v.equals("no sugar")) appendLine(label, "No Sugar");
        else if (v.equals("slight sugar")) appendLine(label, "Slight Sugar");
        else if (v.equals("less sugar")) appendLine(label, "Less Sugar");
        else appendLine(label, value);
    }

    private static void appendIce(StringBuilder label, String value) {
        String v = normalize(value);
        if (v.isEmpty() || v.equals("regular ice") || v.equals("regular") || v.equals("normal")) return;
        if (v.equals("no ice") || v.equals("ice free")) appendLine(label, "No Ice");
        else if (v.equals("less ice") || v.equals("light")) appendLine(label, "Less Ice");
        else appendLine(label, value);
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US).replace('-', ' ');
    }

    private static void appendLine(StringBuilder text, String value) {
        if (text.length() > 0) text.append(", ");
        text.append(value);
    }

    private void updateCustomerNamePreview(String value) {
        String name = value == null ? "" : value.trim();
        customerNamePreview.setText(name.isEmpty() ? "Customer name" : name);
        customerNamePreview.setTextColor(name.isEmpty() ? Color.GRAY : Color.BLACK);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        orderId = getIntent().getStringExtra(EXTRA_ORDER_ID);
        boolean launchedFromCloverPay = MODIFY_ORDER.equals(getIntent().getAction());
        boolean hasCloverOrder = orderId != null && !orderId.trim().isEmpty();
        // Allow the screen to be tried directly in an emulator before Clover integration exists.
        if (!hasCloverOrder) orderId = "standalone_preview";
        SharedPreferences saved = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(30), dp(24), dp(24));
        page.setBackgroundColor(Color.rgb(248, 248, 246));
        page.addView(text("Boba Label", 26, true));

        TextView instructions = text(hasCloverOrder && launchedFromCloverPay
                ? "Enter the name for this order's drink labels."
                : "Preview mode: enter a name to see it on the sample label. Clover order data is not connected yet.", 16, false);
        instructions.setPadding(0, dp(8), 0, dp(16));
        page.addView(instructions);

        nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Customer name");
        nameInput.setTextSize(18);
        nameInput.setEnabled(true);
        nameInput.setText(saved.getString(orderId, ""));
        page.addView(nameInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        // Preview follows the attached label: order header, customer name, drink, modifiers, timestamp.
        LinearLayout label = new LinearLayout(this);
        label.setOrientation(LinearLayout.VERTICAL);
        label.setPadding(dp(10), dp(8), dp(10), dp(8));
        label.setBackgroundColor(Color.WHITE);
        float density = getResources().getDisplayMetrics().density;
        int labelWidthDp = Math.max(1, (int) (getResources().getDisplayMetrics().widthPixels / density) - dp(48));
        int labelHeightDp = Math.round(labelWidthDp * TARGET_LABEL_HEIGHT_IN / TARGET_LABEL_WIDTH_IN);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, dp(labelHeightDp));
        labelParams.topMargin = dp(16);
        page.addView(label, labelParams);

        label.addView(text("Kiosk - Dine-in #K157 (1 of 1)", 14, true));
        customerNamePreview = text("Customer name", 14, true);
        customerNamePreview.setPadding(0, dp(2), 0, 0);
        label.addView(customerNamePreview);
        label.addView(text("Matcha Brown Sugar Boba Milk", 15, true));
        TextView modifications = text(sampleModifications(), 12, true);
        label.addView(modifications);
        TextView timestamp = text(new SimpleDateFormat("MM/dd/yyyy h:mm:ss a", Locale.US).format(new Date()), 10, false);
        timestamp.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
        LinearLayout.LayoutParams timestampParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        label.addView(timestamp, timestampParams);

        updateCustomerNamePreview(nameInput.getText().toString());
        nameInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateCustomerNamePreview(s.toString());
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        Button save = new Button(this);
        save.setText("Save name for this order");
        save.setEnabled(true);
        save.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(this, "Enter a customer name first.", Toast.LENGTH_SHORT).show();
                return;
            }
            saved.edit().putString(orderId, name).apply();
            updateCustomerNamePreview(name);
            Toast.makeText(this, hasCloverOrder
                    ? "Name saved for this Clover order."
                    : "Name saved in preview mode.", Toast.LENGTH_SHORT).show();
        });
        page.addView(save);
        page.addView(text("Preview only. Live Clover order data and QL-810W printing are not connected yet.", 14, false));
        setContentView(page);
    }
}








