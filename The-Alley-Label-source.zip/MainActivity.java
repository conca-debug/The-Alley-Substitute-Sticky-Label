package com.example.bobalabel;

import android.accounts.Account;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.clover.sdk.util.CloverAccount;
import com.clover.sdk.v1.Intents;
import com.clover.sdk.v1.ServiceConnector;
import com.clover.sdk.v3.order.LineItem;
import com.clover.sdk.v3.order.Modification;
import com.clover.sdk.v3.order.Order;
import com.clover.sdk.v3.order.OrderConnector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Drink ordering screen. Clover handles order records and payment; this app supplies the menu UI. */
public final class MainActivity extends Activity {
    private static final int DK_070 = 70;
    private static final int DK_095 = 95;
    private static final ExecutorService CLOVER_IO = Executors.newSingleThreadExecutor();

    private static final String[] SERIES_NAMES = {
            "Brown Sugar Boba Series", "Milk Tea Series", "Crunchy Milk Tea Slushy Series",
            "The Alley Specialty", "Original Brew Tea Series", "Cold Brew Series"
    };
    private static final int[] SERIES_COLORS = {
            Color.rgb(154, 91, 57), Color.rgb(92, 145, 119), Color.rgb(122, 106, 169),
            Color.rgb(222, 137, 72), Color.rgb(75, 142, 172), Color.rgb(191, 97, 111)
    };

    private static final List<MenuDrink> MENU = Arrays.asList(
            new MenuDrink(SERIES_NAMES[0], "Brown Sugar Boba Crème Brûlée Cold Brew", 695),
            new MenuDrink(SERIES_NAMES[0], "Brown Sugar Boba Crème Brûlée Milk", 745),
            new MenuDrink(SERIES_NAMES[0], "Brown Sugar Boba Milk", 745),
            new MenuDrink(SERIES_NAMES[0], "Matcha Brown Sugar Boba Milk", 745),
            new MenuDrink(SERIES_NAMES[0], "Ube Taro Brown Sugar Boba Milk", 775),
            new MenuDrink(SERIES_NAMES[0], "Ube Brown Sugar Boba Crème Brûlée Milk", 775),
            new MenuDrink(SERIES_NAMES[1], "Jasmine Green Milk Tea", 595),
            new MenuDrink(SERIES_NAMES[1], "Assam Black Milk Tea", 595),
            new MenuDrink(SERIES_NAMES[1], "Royal No.9 Milk Tea", 625),
            new MenuDrink(SERIES_NAMES[1], "Thai Milk Tea", 625),
            new MenuDrink(SERIES_NAMES[1], "Ube Milk Tea", 625),
            new MenuDrink(SERIES_NAMES[1], "Mango Green Milk Tea", 645),
            new MenuDrink(SERIES_NAMES[1], "Garden Milk Tea", 645),
            new MenuDrink(SERIES_NAMES[1], "The Alley Trio Milk Tea", 675),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Tiramisu Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Oreo Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Thai Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Strawberry Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[3], "Strawberry Green Tea with Jelly", 695),
            new MenuDrink(SERIES_NAMES[3], "Passion Fruit Green Tea", 695),
            new MenuDrink(SERIES_NAMES[3], "Orange Peach Oolong", 745),
            new MenuDrink(SERIES_NAMES[3], "Lychee Green Tea", 745),
            new MenuDrink(SERIES_NAMES[3], "Snow Strawberry Smoothie", 745),
            new MenuDrink(SERIES_NAMES[3], "Mango Coconut Milk Smoothie", 745),
            new MenuDrink(SERIES_NAMES[3], "Snow Velvet Mango Smoothie", 775),
            new MenuDrink(SERIES_NAMES[3], "Ube Taro Smoothie", 775),
            new MenuDrink(SERIES_NAMES[3], "Original Purple Rice Yogurt", 775),
            new MenuDrink(SERIES_NAMES[3], "Matcha Purple Rice Yogurt", 775),
            new MenuDrink(SERIES_NAMES[3], "Mango Purple Rice Yogurt", 775),
            new MenuDrink(SERIES_NAMES[3], "Fruit Yogurt Smoothie", 775),
            new MenuDrink(SERIES_NAMES[4], "Assam Black Tea", 525),
            new MenuDrink(SERIES_NAMES[4], "Jasmine Green Tea", 525),
            new MenuDrink(SERIES_NAMES[4], "Royal No.9 Black Tea", 575),
            new MenuDrink(SERIES_NAMES[4], "Peach Oolong Tea", 625),
            new MenuDrink(SERIES_NAMES[5], "Snow Velvet Cold Brew", 595),
            new MenuDrink(SERIES_NAMES[5], "Brown Sugar Cream Cold Brew", 645),
            new MenuDrink(SERIES_NAMES[5], "Milk Tea Cold Brew", 645),
            new MenuDrink(SERIES_NAMES[5], "Cocoa Cream Cold Brew", 645)
    );

    private static final String[] ICE_OPTIONS = {"Regular Ice", "Less Ice", "No Ice"};
    private static final String[] SUGAR_OPTIONS = {"Regular Sugar", "Less Sugar", "Slight Sugar", "No Sugar"};
    private static final Topping[] TOPPINGS = {
            new Topping("Boba", DK_070),
            new Topping("Passion Fruit Coconut Jelly", DK_070),
            new Topping("Green Tea Jelly", DK_070),
            new Topping("Lychee Coconut Jelly", DK_070),
            new Topping("House-Made Lychee Jelly", DK_070),
            new Topping("Brown Sugar Boba", DK_095),
            new Topping("Pudding", DK_095),
            new Topping("Crystal Boba", DK_095),
            new Topping("Snow Velvet", DK_095)
    };

    private final ArrayList<DrinkOrder> cart = new ArrayList<>();
    private EditText customerName;
    private EditText searchInput;
    private LinearLayout menuResults;
    private LinearLayout cartRows;
    private TextView totalText;
    private Button checkoutButton;
    private String selectedSeries;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView heading(String value, float size) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(Color.rgb(45, 37, 32));
        v.setTextSize(size);
        v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }

    private TextView label(String value) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(15);
        v.setPadding(0, dp(12), 0, dp(4));
        return v;
    }

    private RadioGroup options(String[] values, int selected) {
        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.VERTICAL);
        for (int i = 0; i < values.length; i++) {
            RadioButton b = new RadioButton(this);
            b.setId(View.generateViewId());
            b.setText(values[i]);
            b.setTextSize(13);
            b.setPadding(0, 0, dp(7), 0);
            group.addView(b, new RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (i == selected) group.check(b.getId());
        }
        return group;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildOrderingScreen();
    }

    private void buildOrderingScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(24));
        page.setBackgroundColor(Color.rgb(248, 248, 246));
        scroll.addView(page);

        page.addView(heading("The Alley Label", 26));
        TextView note = new TextView(this);
        note.setText("Build the drinks here. Clover will handle checkout. All drinks are large (22 oz). Regular ice and sugar are the defaults.");
        note.setTextSize(14);
        note.setPadding(0, dp(5), 0, dp(8));
        page.addView(note);

        customerName = new EditText(this);
        customerName.setSingleLine(true);
        customerName.setHint("Customer name (printed on each cup label)");
        customerName.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        page.addView(customerName, new LinearLayout.LayoutParams(-1, dp(54)));

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint("Search drinks");
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        page.addView(searchInput, new LinearLayout.LayoutParams(-1, dp(52)));
        page.addView(label("Menu"));
        menuResults = new LinearLayout(this);
        menuResults.setOrientation(LinearLayout.VERTICAL);
        page.addView(menuResults);
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderMenuResults(s.toString());
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        page.addView(label("Order"));
        cartRows = new LinearLayout(this);
        cartRows.setOrientation(LinearLayout.VERTICAL);
        cartRows.setPadding(dp(10), dp(6), dp(10), dp(6));
        cartRows.setBackgroundColor(Color.WHITE);
        page.addView(cartRows, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));

        totalText = heading("Total: $0.00", 18);
        totalText.setGravity(Gravity.RIGHT);
        totalText.setPadding(0, dp(12), 0, dp(4));
        page.addView(totalText);

        checkoutButton = new Button(this);
        checkoutButton.setText("Send order to Clover checkout");
        checkoutButton.setOnClickListener(v -> sendOrderToClover());
        page.addView(checkoutButton);

        TextView status = new TextView(this);
        status.setText("Checkout requires this app to be installed on a Clover Station or Mini. A desktop emulator can preview the ordering screen but cannot access your merchant account.");
        status.setTextSize(12);
        status.setPadding(0, dp(6), 0, 0);
        page.addView(status);
        setContentView(scroll);
        renderMenuResults("");
        refreshCart();
    }

    private void renderMenuResults(String rawQuery) {
        menuResults.removeAllViews();
        String query = rawQuery == null ? "" : rawQuery.trim().toLowerCase(Locale.US);
        if (query.isEmpty() && selectedSeries == null) {
            renderSeriesFolders();
            return;
        }

        if (query.isEmpty()) {
            Button back = new Button(this);
            back.setText("‹  All drink series");
            back.setOnClickListener(v -> {
                selectedSeries = null;
                renderMenuResults(searchInput.getText().toString());
            });
            menuResults.addView(back, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            menuResults.addView(heading(selectedSeries, 20), new LinearLayout.LayoutParams(-1, dp(48)));
        }

        int matches = 0;
        for (String series : SERIES_NAMES) {
            if (query.isEmpty() && !series.equals(selectedSeries)) continue;
            ArrayList<MenuDrink> inSeries = new ArrayList<>();
            for (MenuDrink drink : MENU) {
                if (drink.series.equals(series) && (query.isEmpty() || drink.name.toLowerCase(Locale.US).contains(query))) {
                    inSeries.add(drink);
                }
            }
            if (inSeries.isEmpty()) continue;
            if (!query.isEmpty()) {
                menuResults.addView(heading(series, 18), new LinearLayout.LayoutParams(-1, dp(40)));
            }
            for (MenuDrink drink : inSeries) {
                matches++;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(10), dp(5), dp(6), dp(5));
                row.setBackgroundColor(Color.WHITE);
                TextView namePrice = new TextView(this);
                namePrice.setText(drink.name + "\n" + money(drink.priceCents));
                namePrice.setTextSize(14);
                row.addView(namePrice, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                Button select = new Button(this);
                select.setText("Add");
                select.setOnClickListener(v -> showDrinkCustomizer(drink));
                row.addView(select);
                row.setOnClickListener(v -> showDrinkCustomizer(drink));
                menuResults.addView(row, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
                View divider = new View(this);
                divider.setBackgroundColor(Color.rgb(232, 228, 222));
                menuResults.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            }
        }
        if (matches == 0) {
            TextView empty = new TextView(this);
            empty.setText("No drinks match “" + rawQuery.trim() + "”.");
            empty.setTextSize(14);
            empty.setPadding(dp(8), dp(12), dp(8), dp(12));
            menuResults.addView(empty);
        }
    }

    private void renderSeriesFolders() {
        TextView intro = new TextView(this);
        intro.setText("Choose a drink series to start an order");
        intro.setTextSize(14);
        intro.setTextColor(Color.rgb(100, 91, 84));
        intro.setPadding(dp(2), dp(2), dp(2), dp(8));
        menuResults.addView(intro);

        for (int i = 0; i < SERIES_NAMES.length; i++) {
            final String series = SERIES_NAMES[i];
            int count = 0;
            for (MenuDrink drink : MENU) if (drink.series.equals(series)) count++;
            int color = SERIES_COLORS[i];

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setMinimumHeight(dp(60));
            android.graphics.drawable.GradientDrawable cardShape = new android.graphics.drawable.GradientDrawable();
            cardShape.setColor(Color.WHITE);
            cardShape.setCornerRadius(dp(7));
            cardShape.setStroke(dp(1), Color.rgb(224, 218, 211));
            card.setBackground(cardShape);

            LinearLayout textColumn = new LinearLayout(this);
            textColumn.setOrientation(LinearLayout.VERTICAL);
            textColumn.setGravity(Gravity.CENTER_VERTICAL);
            textColumn.setPadding(dp(12), dp(8), dp(6), dp(8));
            TextView title = heading(series, 16);
            title.setTextColor(Color.rgb(55, 46, 40));
            TextView subtitle = new TextView(this);
            subtitle.setText(count + (count == 1 ? " drink" : " drinks"));
            subtitle.setTextSize(12);
            subtitle.setTextColor(Color.rgb(121, 112, 104));
            textColumn.addView(title);
            textColumn.addView(subtitle);
            card.addView(textColumn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            View colorEdge = new View(this);
            android.graphics.drawable.GradientDrawable edgeShape = new android.graphics.drawable.GradientDrawable();
            edgeShape.setColor(color);
            edgeShape.setCornerRadii(new float[]{0, 0, dp(7), dp(7), dp(7), dp(7), 0, 0});
            colorEdge.setBackground(edgeShape);
            card.addView(colorEdge, new LinearLayout.LayoutParams(dp(7), dp(60)));
            card.setOnClickListener(v -> {
                selectedSeries = series;
                renderMenuResults(searchInput.getText().toString());
            });
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
            cardParams.bottomMargin = dp(8);
            menuResults.addView(card, cardParams);
        }
    }

    private void showDrinkCustomizer(MenuDrink drink) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(8));
        panel.addView(label("Ice"));
        RadioGroup ice = options(ICE_OPTIONS, 0);
        panel.addView(ice);
        panel.addView(label("Sugar"));
        RadioGroup sugar = options(SUGAR_OPTIONS, 0);
        panel.addView(sugar);
        panel.addView(label("Optional toppings"));
        TextView priceHint = new TextView(this);
        priceHint.setText("$0.70: Boba and jellies · $0.95: Brown Sugar Boba, Pudding, Crystal Boba, Snow Velvet");
        priceHint.setTextSize(12);
        panel.addView(priceHint);
        ArrayList<CheckBox> boxes = new ArrayList<>();
        for (Topping topping : TOPPINGS) {
            CheckBox box = new CheckBox(this);
            box.setText(topping.name + "  (" + money(topping.priceCents) + ")");
            box.setTextSize(14);
            boxes.add(box);
            panel.addView(box);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setPadding(dp(4), dp(2), dp(4), dp(2));
        scroll.addView(panel);
        new AlertDialog.Builder(this)
                .setTitle(drink.name + " · " + money(drink.priceCents))
                .setView(scroll)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add to order", (dialog, which) -> {
                    ArrayList<Topping> chosenToppings = new ArrayList<>();
                    for (int i = 0; i < TOPPINGS.length; i++) {
                        if (boxes.get(i).isChecked()) chosenToppings.add(TOPPINGS[i]);
                    }
                    String selectedIce = selectedValue(ice, ICE_OPTIONS, 0);
                    String selectedSugar = selectedValue(sugar, SUGAR_OPTIONS, 0);
                    cart.add(new DrinkOrder(drink, selectedIce, selectedSugar, chosenToppings));
                    refreshCart();
                    Toast.makeText(this, drink.name + " added", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private String selectedValue(RadioGroup group, String[] values, int fallback) {
        int checked = group.indexOfChild(group.findViewById(group.getCheckedRadioButtonId()));
        return values[checked >= 0 && checked < values.length ? checked : fallback];
    }

    private void refreshCart() {
        cartRows.removeAllViews();
        if (cart.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No drinks added yet.");
            empty.setPadding(0, dp(5), 0, dp(5));
            cartRows.addView(empty);
        } else {
            for (int i = 0; i < cart.size(); i++) {
                final int itemIndex = i;
                DrinkOrder item = cart.get(i);
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(5), 0, dp(5));
                row.setOrientation(LinearLayout.HORIZONTAL);
                TextView details = new TextView(this);
                details.setText(item.summary() + "  " + money(item.totalCents()));
                details.setTextSize(13);
                row.addView(details, new LinearLayout.LayoutParams(0, -2, 1f));
                Button remove = new Button(this);
                remove.setText("Remove");
                remove.setOnClickListener(v -> { cart.remove(itemIndex); refreshCart(); });
                row.addView(remove);
                cartRows.addView(row);
                if (i < cart.size() - 1) {
                    View divider = new View(this);
                    divider.setBackgroundColor(Color.LTGRAY);
                    cartRows.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
                }
            }
        }
        int total = 0;
        for (DrinkOrder drink : cart) total += drink.totalCents();
        totalText.setText("Total: " + money(total));
        checkoutButton.setEnabled(!cart.isEmpty());
    }

    private void sendOrderToClover() {
        String name = customerName.getText().toString().trim();
        if (name.isEmpty()) {
            customerName.setError("Enter the customer's name");
            customerName.requestFocus();
            return;
        }
        Account account = CloverAccount.getAccount(getApplicationContext());
        if (account == null) {
            Toast.makeText(this, "Clover checkout is available when this app runs on your Clover Station or Mini.", Toast.LENGTH_LONG).show();
            return;
        }
        checkoutButton.setEnabled(false);
        checkoutButton.setText("Creating Clover order…");
        ArrayList<DrinkOrder> orderToSend = new ArrayList<>(cart);
        CLOVER_IO.execute(() -> createCloverOrder(account, name, orderToSend));
    }

    private void createCloverOrder(Account account, String name, ArrayList<DrinkOrder> items) {
        CountDownLatch connected = new CountDownLatch(1);
        OrderConnector connector = new OrderConnector(getApplicationContext(), account, new ServiceConnector.OnServiceConnectedListener() {
            @Override public void onServiceConnected(ServiceConnector<?> serviceConnector) { connected.countDown(); }
            @Override public void onServiceDisconnected(ServiceConnector<?> serviceConnector) {}
        });
        try {
            if (!connector.connect() || !connected.await(15, TimeUnit.SECONDS)) {
                showCheckoutError("Could not connect to Clover order service.");
                return;
            }
            Order order = new Order();
            order.setTitle(("Boba - " + name).substring(0, Math.min(127, ("Boba - " + name).length())));
            Order created = connector.createOrder(order);
            if (created == null || created.getId() == null) throw new IllegalStateException("Clover did not return an order ID.");

            for (DrinkOrder drink : items) {
                LineItem lineItem = new LineItem();
                lineItem.setName(drink.drink.name);
                lineItem.setPrice((long) drink.drink.priceCents);
                lineItem.setNote(drink.noteForClover());
                List<Modification> mods = new ArrayList<>();
                for (String selected : drink.printableDefaults()) {
                    Modification mod = new Modification();
                    mod.setName(selected);
                    mod.setAmount(0L);
                    mods.add(mod);
                }
                for (Topping topping : drink.toppings) {
                    Modification mod = new Modification();
                    mod.setName(topping.name);
                    mod.setAmount((long) topping.priceCents);
                    mods.add(mod);
                }
                lineItem.setModifications(mods);
                connector.addCustomLineItem(created.getId(), lineItem, true);
            }

            getSharedPreferences("label_names", MODE_PRIVATE).edit().putString(created.getId(), name).apply();
            Intent register = new Intent(Intents.ACTION_START_REGISTER);
            register.putExtra(Intents.EXTRA_ORDER_ID, created.getId());
            register.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            runOnUiThread(() -> {
                try {
                    startActivity(register);
                    cart.clear();
                    refreshCart();
                    checkoutButton.setText("Send order to Clover checkout");
                } catch (Exception e) {
                    checkoutButton.setEnabled(true);
                    checkoutButton.setText("Send order to Clover checkout");
                    Toast.makeText(this, "Order created, but Clover Register could not open: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        } catch (Exception e) {
            showCheckoutError("Could not create Clover order: " + e.getMessage());
        } finally {
            connector.disconnect();
        }
    }

    private void showCheckoutError(String message) {
        runOnUiThread(() -> {
            checkoutButton.setEnabled(!cart.isEmpty());
            checkoutButton.setText("Send order to Clover checkout");
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    private static String money(int cents) {
        return String.format(Locale.US, "$%d.%02d", cents / 100, cents % 100);
    }

    private static final class MenuDrink {
        final String series;
        final String name;
        final int priceCents;
        MenuDrink(String series, String name, int priceCents) {
            this.series = series;
            this.name = name;
            this.priceCents = priceCents;
        }
    }

    private static final class Topping {
        final String name;
        final int priceCents;
        Topping(String name, int priceCents) { this.name = name; this.priceCents = priceCents; }
    }

    private static final class DrinkOrder {
        final MenuDrink drink;
        final String ice;
        final String sugar;
        final List<Topping> toppings;
        DrinkOrder(MenuDrink drink, String ice, String sugar, List<Topping> toppings) {
            this.drink = drink; this.ice = ice; this.sugar = sugar; this.toppings = new ArrayList<>(toppings);
        }
        int totalCents() {
            int total = drink.priceCents;
            for (Topping topping : toppings) total += topping.priceCents;
            return total;
        }
        List<String> printableDefaults() {
            List<String> mods = new ArrayList<>();
            if (!"Regular Ice".equals(ice)) mods.add(ice);
            if (!"Regular Sugar".equals(sugar)) mods.add(sugar);
            return mods;
        }
        String noteForClover() {
            List<String> mods = printableDefaults();
            for (Topping topping : toppings) mods.add(topping.name);
            return mods.isEmpty() ? null : String.join(", ", mods);
        }
        String summary() {
            List<String> mods = printableDefaults();
            for (Topping topping : toppings) mods.add(topping.name);
            return drink.name + (mods.isEmpty() ? "" : " — " + String.join(", ", mods));
        }
    }
}
