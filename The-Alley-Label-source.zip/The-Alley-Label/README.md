# The Alley Label

Android app for entering The Alley drink orders on a Clover Station/Mini. The menu is grouped into the six series shown on the supplied menu, and the search field filters drinks by name. Selecting a drink opens its ice, sugar, and topping choices. A hideable cart sidebar holds added drinks. The customer name is requested at checkout, when the app creates a Clover order and opens Clover Pay for payment.

## Run in Android Studio

Open this folder (the one containing `settings.gradle`) as the project, sync Gradle, and run the `app` configuration on a Clover Station/Mini. A regular phone emulator can show the ordering screen, but it cannot connect to the store's Clover account or create paid Clover orders.

The app must be installed and approved on the Clover merchant device with Clover order write access. If Clover reports a permission error, grant the app the appropriate order permissions in its Clover app configuration.

## Menu behavior

- Default cup: large, 22 oz; size is not shown as a modifier.
- Defaults: Regular Ice and Regular Sugar; these are left off the printed label/customization note.
- Non-default choices: Less Ice, No Ice, Less Sugar, Slight Sugar, No Sugar.
- Toppings are charged at the prices printed in the menu: five toppings at $0.70 and four at $0.95.
- Each cup is entered as an individual Clover line item so its name and customizations can vary.

## Payment and printing status

The app waits for Clover's successful payment result or matching payment-processed event before clearing the cart. Automatic label printing is not complete yet: the Brother Android Print SDK is distributed separately by Brother and must be added before USB printing can be implemented and tested. Intended printer settings are QL-810W over USB, DK-1209 (62 × 28.9 mm landscape), with auto-cut after each label. Do not treat order-created or order-saved events as proof of payment.
