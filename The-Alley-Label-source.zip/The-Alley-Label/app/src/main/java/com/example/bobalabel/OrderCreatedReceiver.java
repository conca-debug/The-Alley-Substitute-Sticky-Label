package com.example.bobalabel;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Receives Clover order lifecycle events. Keep processing out of this short callback. */
public final class OrderCreatedReceiver extends BroadcastReceiver {
    private static final String TAG = "BobaLabel";
    private static final String EXTRA_ORDER_ID = "com.clover.intent.extra.ORDER_ID";
    private static final String ORDER_CREATED = "com.clover.intent.action.ORDER_CREATED";
    private static final String ORDER_SAVED = "com.clover.intent.action.ORDER_SAVED";
    private static final String PAYMENT_PROCESSED = "com.clover.intent.action.PAYMENT_PROCESSED";

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!ORDER_CREATED.equals(action) && !ORDER_SAVED.equals(action) && !PAYMENT_PROCESSED.equals(action)) return;
        String orderId = intent.getStringExtra(EXTRA_ORDER_ID);
        if (orderId == null || orderId.trim().isEmpty()) {
            Log.w(TAG, "Clover event did not include an order ID: " + action);
            return;
        }
        if (PAYMENT_PROCESSED.equals(action)) {
            context.getSharedPreferences("label_names", Context.MODE_PRIVATE)
                    .edit().putString("payment_processed_order_id", orderId).apply();
        }
        // Printing must be triggered only from PAYMENT_PROCESSED, after Brother support is added.
        Log.i(TAG, "Order lifecycle event " + action + " for " + orderId);
    }
}
