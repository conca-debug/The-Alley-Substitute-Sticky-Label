package com.example.bobalabel;

import android.accounts.Account;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.clover.sdk.util.CloverAccount;
import com.clover.sdk.v1.Intents;
import com.clover.sdk.v1.ServiceConnector;
import com.clover.sdk.v3.order.LineItem;
import com.clover.sdk.v3.order.Modification;
import com.clover.sdk.v3.order.Order;
import com.clover.sdk.v3.order.OrderConnector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Drink ordering screen. Clover handles order records and payment; this app supplies the menu UI. */
public final class MainActivity extends Activity {
    private static final int REQUEST_CLOVER_PAY = 201;
    private static final int DK_070 = 70;
    private static final int DK_095 = 95;
    private static final ExecutorService CLOVER_IO = Executors.newSingleThreadExecutor();

    private static final String[] SERIES_NAMES = {
            "Brown Sugar Boba Series", "Milk Tea Series", "Crunchy Milk Tea Slushy Series",
            "The Alley Specialty", "Original Brew Tea Series", "Cold Brew Series"
    };
    private static final int[] SERIES_COLORS = {
            Color.rgb(154, 91, 57), Color.rgb(92, 145, 119), Color.rgb(122, 106, 169),
            Color.rgb(222, 137, 72), Color.rgb(75, 142, 172), Color.rgb(191, 97, 111)
    };

    private static final List<MenuDrink> MENU = Arrays.asList(
            new MenuDrink(SERIES_NAMES[0], "Brown Sugar Boba Crème Brûlée Cold Brew", 695),
            new MenuDrink(SERIES_NAMES[0], "Brown Sugar Boba Crème Brûlée Milk", 745),
            new MenuDrink(SERIES_NAMES[0], "Brown Sugar Boba Milk", 745),
            new MenuDrink(SERIES_NAMES[0], "Matcha Brown Sugar Boba Milk", 745),
            new MenuDrink(SERIES_NAMES[0], "Ube Taro Brown Sugar Boba Milk", 775),
            new MenuDrink(SERIES_NAMES[0], "Ube Brown Sugar Boba Crème Brûlée Milk", 775),
            new MenuDrink(SERIES_NAMES[1], "Jasmine Green Milk Tea", 595),
            new MenuDrink(SERIES_NAMES[1], "Assam Black Milk Tea", 595),
            new MenuDrink(SERIES_NAMES[1], "Royal No.9 Milk Tea", 625),
            new MenuDrink(SERIES_NAMES[1], "Thai Milk Tea", 625),
            new MenuDrink(SERIES_NAMES[1], "Ube Milk Tea", 625),
            new MenuDrink(SERIES_NAMES[1], "Mango Green Milk Tea", 645),
            new MenuDrink(SERIES_NAMES[1], "Garden Milk Tea", 645),
            new MenuDrink(SERIES_NAMES[1], "The Alley Trio Milk Tea", 675),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Tiramisu Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Oreo Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Thai Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[2], "Crunchy Strawberry Milk Tea Slushy", 695),
            new MenuDrink(SERIES_NAMES[3], "Strawberry Green Tea with Jelly", 695),
            new MenuDrink(SERIES_NAMES[3], "Passion Fruit Green Tea", 695),
            new MenuDrink(SERIES_NAMES[3], "Orange Peach Oolong", 745),
            new MenuDrink(SERIES_NAMES[3], "Lychee Green Tea", 745),
            new MenuDrink(SERIES_NAMES[3], "Snow Strawberry Smoothie", 745),
            new MenuDrink(SERIES_NAMES[3], "Mango Coconut Milk Smoothie", 745),
            new MenuDrink(SERIES_NAMES[3], "Snow Velvet Mango Smoothie", 775),
            new MenuDrink(SERIES_NAMES[3], "Ube Taro Smoothie", 775),
            new MenuDrink(SERIES_NAMES[3], "Original Purple Rice Yogurt", 775),
            new MenuDrink(SERIES_NAMES[3], "Matcha Purple Rice Yogurt", 775),
            new MenuDrink(SERIES_NAMES[3], "Mango Purple Rice Yogurt", 775),
            new MenuDrink(SERIES_NAMES[3], "Fruit Yogurt Smoothie", 775),
            new MenuDrink(SERIES_NAMES[4], "Assam Black Tea", 525),
            new MenuDrink(SERIES_NAMES[4], "Jasmine Green Tea", 525),
            new MenuDrink(SERIES_NAMES[4], "Royal No.9 Black Tea", 575),
            new MenuDrink(SERIES_NAMES[4], "Peach Oolong Tea", 625),
            new MenuDrink(SERIES_NAMES[5], "Snow Velvet Cold Brew", 595),
            new MenuDrink(SERIES_NAMES[5], "Brown Sugar Cream Cold Brew", 645),
            new MenuDrink(SERIES_NAMES[5], "Milk Tea Cold Brew", 645),
            new MenuDrink(SERIES_NAMES[5], "Cocoa Cream Cold Brew", 645)
    );

    private static final String[] ICE_OPTIONS = {"Regular Ice", "Less Ice", "No Ice"};
    private static final String[] SUGAR_OPTIONS = {"Regular Sugar", "Less Sugar", "Slight Sugar", "No Sugar"};
    private static final Topping[] TOPPINGS = {
            new Topping("Boba", DK_070),
            new Topping("Passion Fruit Coconut Jelly", DK_070),
            new Topping("Green Tea Jelly", DK_070),
            new Topping("Lychee Coconut Jelly", DK_070),
            new Topping("House-Made Lychee Jelly", DK_070),
            new Topping("Brown Sugar Boba", DK_095),
            new Topping("Pudding", DK_095),
            new Topping("Crystal Boba", DK_095),
            new Topping("Snow Velvet", DK_095)
    };

    private final ArrayList<DrinkOrder> cart = new ArrayList<>();
    private EditText searchInput;
    private LinearLayout menuResults;
    private LinearLayout cartSidebar;
    private LinearLayout cartRows;
    private TextView totalText;
    private Button checkoutButton;
    private Button cartToggleButton;
    private boolean cartSidebarOpen;
    private boolean checkoutInProgress;
    private String selectedSeries;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView heading(String value, float size) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(Color.rgb(45, 37, 32));
        v.setTextSize(size);
        v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }

    private TextView label(String value) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(15);
        v.setPadding(0, dp(12), 0, dp(4));
        return v;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildOrderingScreen();
    }

    private void buildOrderingScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(248, 248, 246));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(24));
        page.setBackgroundColor(Color.rgb(248, 248, 246));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        titleBar.setOrientation(LinearLayout.HORIZONTAL);
        TextView appTitle = heading("The Alley Label", 26);
        titleBar.addView(appTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cartToggleButton = new Button(this);
        cartToggleButton.setText("Cart (0)");
        cartToggleButton.setOnClickListener(v -> setCartSidebarOpen(!cartSidebarOpen));
        titleBar.addView(cartToggleButton);
        page.addView(titleBar);

        TextView note = new TextView(this);
        note.setText("Build the drinks here. Clover will handle checkout. All drinks are large (22 oz). Regular ice and sugar are the defaults.");
        note.setTextSize(14);
        note.setPadding(0, dp(5), 0, dp(8));
        page.addView(note);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint("Search drinks");
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        page.addView(searchInput, new LinearLayout.LayoutParams(-1, dp(52)));
        page.addView(label("Menu"));
        menuResults = new LinearLayout(this);
        menuResults.setOrientation(LinearLayout.VERTICAL);
        page.addView(menuResults);
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderMenuResults(s.toString());
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        setContentView(root);

        cartSidebar = new LinearLayout(this);
        cartSidebar.setOrientation(LinearLayout.VERTICAL);
        cartSidebar.setPadding(dp(14), dp(12), dp(14), dp(14));
        cartSidebar.setBackgroundColor(Color.WHITE);
        cartSidebar.setElevation(dp(12));

        LinearLayout sidebarHeader = new LinearLayout(this);
        sidebarHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView cartHeading = heading("Current order", 20);
        sidebarHeader.addView(cartHeading, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button closeCart = new Button(this);
        closeCart.setText("Hide");
        closeCart.setOnClickListener(v -> setCartSidebarOpen(false));
        sidebarHeader.addView(closeCart);
        cartSidebar.addView(sidebarHeader);

        cartRows = new LinearLayout(this);
        cartRows.setOrientation(LinearLayout.VERTICAL);
        cartRows.setPadding(dp(8), dp(6), dp(8), dp(6));
        ScrollView cartScroll = new ScrollView(this);
        cartScroll.setFillViewport(true);
        cartScroll.addView(cartRows);
        cartSidebar.addView(cartScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        totalText = heading("Total: $0.00", 18);
        totalText.setGravity(Gravity.RIGHT);
        totalText.setPadding(0, dp(12), 0, dp(4));
        cartSidebar.addView(totalText);

        checkoutButton = new Button(this);
        checkoutButton.setText("Checkout");
        checkoutButton.setOnClickListener(v -> sendOrderToClover());
        cartSidebar.addView(checkoutButton);

        TextView status = new TextView(this);
        status.setText("Clover will take payment. Labels are not connected to the Brother printer yet.");
        status.setTextSize(12);
        status.setPadding(0, dp(6), 0, 0);
        cartSidebar.addView(status);

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int sidebarWidth = Math.min(dp(390), (int) (screenWidth * 0.86f));
        FrameLayout.LayoutParams sidebarParams = new FrameLayout.LayoutParams(sidebarWidth, -1, Gravity.RIGHT | Gravity.TOP);
        root.addView(cartSidebar, sidebarParams);
        boolean wideScreen = getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
                || getResources().getConfiguration().smallestScreenWidthDp >= 600;
        cartSidebarOpen = wideScreen;
        setCartSidebarOpen(cartSidebarOpen);

        renderMenuResults("");
        refreshCart();
    }

    private void setCartSidebarOpen(boolean open) {
        cartSidebarOpen = open;
        if (cartSidebar != null) cartSidebar.setVisibility(open ? View.VISIBLE : View.GONE);
        if (cartToggleButton != null) {
            int count = cart == null ? 0 : cart.size();
            cartToggleButton.setText(open ? "Cart open · " + count : "Cart · " + count);
        }
    }

    private void renderMenuResults(String rawQuery) {
        menuResults.removeAllViews();
        String query = rawQuery == null ? "" : rawQuery.trim().toLowerCase(Locale.US);
        if (query.isEmpty() && selectedSeries == null) {
            renderSeriesFolders();
            return;
        }

        if (query.isEmpty()) {
            Button back = new Button(this);
            back.setText("‹  All drink series");
            back.setOnClickListener(v -> {
                selectedSeries = null;
                renderMenuResults(searchInput.getText().toString());
            });
            menuResults.addView(back, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            menuResults.addView(heading(selectedSeries, 20), new LinearLayout.LayoutParams(-1, dp(48)));
        }

        int matches = 0;
        for (String series : SERIES_NAMES) {
            if (query.isEmpty() && !series.equals(selectedSeries)) continue;
            ArrayList<MenuDrink> inSeries = new ArrayList<>();
            for (MenuDrink drink : MENU) {
                if (drink.series.equals(series) && (query.isEmpty() || drink.name.toLowerCase(Locale.US).contains(query))) {
                    inSeries.add(drink);
                }
            }
            if (inSeries.isEmpty()) continue;
            if (!query.isEmpty()) {
                menuResults.addView(heading(series, 18), new LinearLayout.LayoutParams(-1, dp(40)));
            }
            for (MenuDrink drink : inSeries) {
                matches++;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(10), dp(5), dp(6), dp(5));
                row.setBackgroundColor(Color.WHITE);
                TextView namePrice = new TextView(this);
                namePrice.setText(drink.name + "\n" + money(drink.priceCents));
                namePrice.setTextSize(14);
                row.addView(namePrice, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                Button select = new Button(this);
                select.setText("Add");
                select.setOnClickListener(v -> showDrinkCustomizer(drink));
                row.addView(select);
                row.setOnClickListener(v -> showDrinkCustomizer(drink));
                menuResults.addView(row, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
                View divider = new View(this);
                divider.setBackgroundColor(Color.rgb(232, 228, 222));
                menuResults.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            }
        }
        if (matches == 0) {
            TextView empty = new TextView(this);
            empty.setText("No drinks match “" + rawQuery.trim() + "”.");
            empty.setTextSize(14);
            empty.setPadding(dp(8), dp(12), dp(8), dp(12));
            menuResults.addView(empty);
        }
    }

    private void renderSeriesFolders() {
        TextView intro = new TextView(this);
        intro.setText("Choose a drink series to start an order");
        intro.setTextSize(14);
        intro.setTextColor(Color.rgb(100, 91, 84));
        intro.setPadding(dp(2), dp(2), dp(2), dp(8));
        menuResults.addView(intro);

        for (int i = 0; i < SERIES_NAMES.length; i++) {
            final String series = SERIES_NAMES[i];
            int count = 0;
            for (MenuDrink drink : MENU) if (drink.series.equals(series)) count++;
            int color = SERIES_COLORS[i];

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setMinimumHeight(dp(60));
            android.graphics.drawable.GradientDrawable cardShape = new android.graphics.drawable.GradientDrawable();
            cardShape.setColor(Color.WHITE);
            cardShape.setCornerRadius(dp(7));
            cardShape.setStroke(dp(1), Color.rgb(224, 218, 211));
            card.setBackground(cardShape);

            LinearLayout textColumn = new LinearLayout(this);
            textColumn.setOrientation(LinearLayout.VERTICAL);
            textColumn.setGravity(Gravity.CENTER_VERTICAL);
            textColumn.setPadding(dp(12), dp(8), dp(6), dp(8));
            TextView title = heading(series, 16);
            title.setTextColor(Color.rgb(55, 46, 40));
            TextView subtitle = new TextView(this);
            subtitle.setText(count + (count == 1 ? " drink" : " drinks"));
            subtitle.setTextSize(12);
            subtitle.setTextColor(Color.rgb(121, 112, 104));
            textColumn.addView(title);
            textColumn.addView(subtitle);
            card.addView(textColumn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            View colorEdge = new View(this);
            android.graphics.drawable.GradientDrawable edgeShape = new android.graphics.drawable.GradientDrawable();
            edgeShape.setColor(color);
            edgeShape.setCornerRadii(new float[]{0, 0, dp(7), dp(7), dp(7), dp(7), 0, 0});
            colorEdge.setBackground(edgeShape);
            card.addView(colorEdge, new LinearLayout.LayoutParams(dp(7), dp(60)));
            card.setOnClickListener(v -> {
                selectedSeries = series;
                renderMenuResults(searchInput.getText().toString());
            });
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
            cardParams.bottomMargin = dp(8);
            menuResults.addView(card, cardParams);
        }
    }

    private void showDrinkCustomizer(MenuDrink drink) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(8));
        boolean fixedIce = SERIES_NAMES[2].equals(drink.series);
        final TileChoices ice;
        if (!fixedIce) {
            panel.addView(label("Ice"));
            ice = addTileChoices(panel, ICE_OPTIONS, false, 0);
        } else {
            ice = null;
        }
        panel.addView(label("Sugar"));
        TileChoices sugar = addTileChoices(panel, SUGAR_OPTIONS, false, 0);
        panel.addView(label("Optional toppings"));
        TextView priceHint = new TextView(this);
        priceHint.setText("$0.70: Boba and jellies · $0.95: Brown Sugar Boba, Pudding, Crystal Boba, Snow Velvet");
        priceHint.setTextSize(12);
        panel.addView(priceHint);
        String[] toppingLabels = new String[TOPPINGS.length];
        for (int i = 0; i < TOPPINGS.length; i++) {
            toppingLabels[i] = TOPPINGS[i].name + "\n" + money(TOPPINGS[i].priceCents);
        }
        TileChoices toppings = addTileChoices(panel, toppingLabels, true, -1);
        ScrollView scroll = new ScrollView(this);
        scroll.setPadding(dp(4), dp(2), dp(4), dp(2));
        scroll.addView(panel);
        new AlertDialog.Builder(this)
                .setTitle(drink.name + " · " + money(drink.priceCents))
                .setView(scroll)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add to order", (dialog, which) -> {
                    ArrayList<Topping> chosenToppings = new ArrayList<>();
                    for (int index : toppings.selectedIndices()) chosenToppings.add(TOPPINGS[index]);
                    String selectedIce = ice == null ? ICE_OPTIONS[0] : ice.selectedValue(ICE_OPTIONS[0]);
                    String selectedSugar = sugar.selectedValue(SUGAR_OPTIONS[0]);
                    cart.add(new DrinkOrder(drink, selectedIce, selectedSugar, chosenToppings));
                    refreshCart();
                    setCartSidebarOpen(true);
                    Toast.makeText(this, drink.name + " added", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private TileChoices addTileChoices(LinearLayout parent, String[] labels, boolean multiSelect, int defaultIndex) {
        TileChoices choices = new TileChoices(labels, multiSelect, defaultIndex);
        LinearLayout row = null;
        for (int i = 0; i < labels.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                parent.addView(row, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            final int index = i;
            TextView tile = new TextView(this);
            tile.setText(labels[i]);
            tile.setTextSize(14);
            tile.setTextColor(Color.rgb(54, 46, 40));
            tile.setTypeface(null, choices.selected[i] ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            tile.setGravity(Gravity.CENTER);
            tile.setMinHeight(dp(48));
            tile.setPadding(dp(8), dp(8), dp(8), dp(8));
            tile.setBackground(tileBackground(choices.selected[i]));
            tile.setOnClickListener(v -> {
                if (choices.multiSelect) {
                    choices.selected[index] = !choices.selected[index];
                } else {
                    Arrays.fill(choices.selected, false);
                    choices.selected[index] = true;
                }
                choices.updateTileStyles();
            });
            choices.tiles.add(tile);
            LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tileParams.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(tile, tileParams);
        }
        return choices;
    }

    private android.graphics.drawable.GradientDrawable tileBackground(boolean selected) {
        android.graphics.drawable.GradientDrawable background = new android.graphics.drawable.GradientDrawable();
        background.setColor(selected ? Color.rgb(232, 225, 216) : Color.rgb(249, 248, 246));
        background.setCornerRadius(dp(7));
        background.setStroke(dp(1), selected ? Color.rgb(193, 175, 155) : Color.rgb(224, 218, 211));
        return background;
    }

    private final class TileChoices {
        final String[] labels;
        final boolean multiSelect;
        final boolean[] selected;
        final ArrayList<TextView> tiles = new ArrayList<>();

        TileChoices(String[] labels, boolean multiSelect, int defaultIndex) {
            this.labels = labels;
            this.multiSelect = multiSelect;
            this.selected = new boolean[labels.length];
            if (defaultIndex >= 0 && defaultIndex < labels.length) selected[defaultIndex] = true;
        }

        void updateTileStyles() {
            for (int i = 0; i < tiles.size(); i++) {
                tiles.get(i).setBackground(tileBackground(selected[i]));
                tiles.get(i).setTypeface(null, selected[i] ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            }
        }

        String selectedValue(String fallback) {
            for (int i = 0; i < selected.length; i++) if (selected[i]) return labels[i];
            return fallback;
        }

        ArrayList<Integer> selectedIndices() {
            ArrayList<Integer> indices = new ArrayList<>();
            for (int i = 0; i < selected.length; i++) if (selected[i]) indices.add(i);
            return indices;
        }
    }

    private void refreshCart() {
        cartRows.removeAllViews();
        if (cart.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No drinks added yet.");
            empty.setPadding(0, dp(5), 0, dp(5));
            cartRows.addView(empty);
        } else {
            for (int i = 0; i < cart.size(); i++) {
                final int itemIndex = i;
                DrinkOrder item = cart.get(i);
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(5), 0, dp(5));
                row.setOrientation(LinearLayout.HORIZONTAL);
                TextView details = new TextView(this);
                details.setText(item.summary() + "  " + money(item.totalCents()));
                details.setTextSize(13);
                row.addView(details, new LinearLayout.LayoutParams(0, -2, 1f));
                Button remove = new Button(this);
                remove.setText("Remove");
                remove.setOnClickListener(v -> { cart.remove(itemIndex); refreshCart(); });
                row.addView(remove);
                cartRows.addView(row);
                if (i < cart.size() - 1) {
                    View divider = new View(this);
                    divider.setBackgroundColor(Color.LTGRAY);
                    cartRows.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
                }
            }
        }
        int total = 0;
        for (DrinkOrder drink : cart) total += drink.totalCents();
        totalText.setText("Total: " + money(total));
        checkoutButton.setEnabled(!cart.isEmpty() && !checkoutInProgress);
        if (cartToggleButton != null) setCartSidebarOpen(cartSidebarOpen);
    }

    private void sendOrderToClover() {
        Account account = CloverAccount.getAccount(getApplicationContext());
        if (account == null) {
            Toast.makeText(this, "Clover checkout is available when this app runs on your Clover Station or Mini.", Toast.LENGTH_LONG).show();
            return;
        }
        String pendingOrderId = getSharedPreferences("label_names", MODE_PRIVATE).getString("pending_order_id", null);
        if (pendingOrderId != null && !pendingOrderId.isEmpty()) {
            launchPendingCloverPayment(pendingOrderId);
            return;
        }

        int totalCents = cartTotalCents();
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Customer name for the cup labels");
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        nameInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout prompt = new LinearLayout(this);
        prompt.setOrientation(LinearLayout.VERTICAL);
        prompt.setPadding(dp(20), dp(4), dp(20), 0);
        TextView chargeInfo = new TextView(this);
        chargeInfo.setText("Enter the customer's name. Clover will charge " + money(totalCents) + " for this order.");
        chargeInfo.setTextSize(14);
        chargeInfo.setPadding(0, 0, 0, dp(8));
        prompt.addView(chargeInfo);
        prompt.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(54)));

        AlertDialog nameDialog = new AlertDialog.Builder(this)
                .setTitle("Checkout")
                .setView(prompt)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Charge " + money(totalCents), null)
                .create();
        nameDialog.setOnShowListener(dialog -> nameDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (name.isEmpty()) {
                nameInput.setError("Enter the customer's name");
                nameInput.requestFocus();
                return;
            }
            nameDialog.dismiss();
            checkoutInProgress = true;
            checkoutButton.setEnabled(false);
            checkoutButton.setText("Charging " + money(totalCents) + " on Clover…");
            ArrayList<DrinkOrder> orderToSend = new ArrayList<>(cart);
            CLOVER_IO.execute(() -> createCloverOrder(account, name, totalCents, orderToSend));
        }));
        nameDialog.show();
        nameDialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    private int cartTotalCents() {
        int total = 0;
        for (DrinkOrder drink : cart) total += drink.totalCents();
        return total;
    }

    private void createCloverOrder(Account account, String name, int totalCents, ArrayList<DrinkOrder> items) {
        CountDownLatch connected = new CountDownLatch(1);
        OrderConnector connector = new OrderConnector(getApplicationContext(), account, new ServiceConnector.OnServiceConnectedListener() {
            @Override public void onServiceConnected(ServiceConnector<?> serviceConnector) { connected.countDown(); }
            @Override public void onServiceDisconnected(ServiceConnector<?> serviceConnector) {}
        });
        try {
            if (!connector.connect() || !connected.await(15, TimeUnit.SECONDS)) {
                showCheckoutError("Could not connect to Clover order service.");
                return;
            }
            Order order = new Order();
            order.setTitle(("Boba - " + name).substring(0, Math.min(127, ("Boba - " + name).length())));
            Order created = connector.createOrder(order);
            if (created == null || created.getId() == null) throw new IllegalStateException("Clover did not return an order ID.");

            for (DrinkOrder drink : items) {
                LineItem lineItem = new LineItem();
                lineItem.setName(drink.drink.name);
                lineItem.setPrice((long) drink.drink.priceCents);
                lineItem.setNote(drink.noteForClover());
                List<Modification> mods = new ArrayList<>();
                for (String selected : drink.printableDefaults()) {
                    Modification mod = new Modification();
                    mod.setName(selected);
                    mod.setAmount(0L);
                    mods.add(mod);
                }
                for (Topping topping : drink.toppings) {
                    Modification mod = new Modification();
                    mod.setName(topping.name);
                    mod.setAmount((long) topping.priceCents);
                    mods.add(mod);
                }
                lineItem.setModifications(mods);
                connector.addCustomLineItem(created.getId(), lineItem, true);
            }

            getSharedPreferences("label_names", MODE_PRIVATE).edit()
                    .putString(created.getId(), name)
                    .putString("pending_order_id", created.getId())
                    .putInt("pending_order_total", totalCents)
                    .apply();
            runOnUiThread(() -> launchPendingCloverPayment(created.getId()));
        } catch (Exception e) {
            showCheckoutError("Could not create Clover order: " + e.getMessage());
        } finally {
            connector.disconnect();
        }
    }

    private void launchPendingCloverPayment(String orderId) {
        int amount = getSharedPreferences("label_names", MODE_PRIVATE).getInt("pending_order_total", cartTotalCents());
        Intent payment = new Intent(Intents.ACTION_CLOVER_PAY);
        payment.putExtra(Intents.EXTRA_CLOVER_ORDER_ID, orderId);
        try {
            checkoutInProgress = false;
            checkoutButton.setText("Charging " + money(amount) + " on Clover…");
            checkoutButton.setEnabled(false);
            startActivityForResult(payment, REQUEST_CLOVER_PAY);
        } catch (Exception e) {
            showCheckoutError("Order created, but Clover payment could not open: " + e.getMessage());
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CLOVER_PAY) return;
        String pendingId = getSharedPreferences("label_names", MODE_PRIVATE).getString("pending_order_id", null);
        if (resultCode == RESULT_OK && pendingId != null) {
            completePaidOrder(pendingId);
        } else if (pendingId != null) {
            checkoutInProgress = false;
            checkoutButton.setText("Resume payment · " + money(getSharedPreferences("label_names", MODE_PRIVATE).getInt("pending_order_total", 0)));
            checkoutButton.setEnabled(!cart.isEmpty());
            Toast.makeText(this, "Payment was not completed. The order is still in your cart.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        String confirmedId = getSharedPreferences("label_names", MODE_PRIVATE).getString("payment_processed_order_id", null);
        String pendingId = getSharedPreferences("label_names", MODE_PRIVATE).getString("pending_order_id", null);
        if (confirmedId != null && confirmedId.equals(pendingId)) {
            completePaidOrder(pendingId);
        } else if (pendingId != null && checkoutButton != null) {
            int amount = getSharedPreferences("label_names", MODE_PRIVATE).getInt("pending_order_total", cartTotalCents());
            checkoutInProgress = false;
            checkoutButton.setText("Resume payment · " + money(amount));
            checkoutButton.setEnabled(!cart.isEmpty());
        }
    }

    private void completePaidOrder(String orderId) {
        android.content.SharedPreferences prefs = getSharedPreferences("label_names", MODE_PRIVATE);
        String pendingId = prefs.getString("pending_order_id", null);
        if (orderId == null || !orderId.equals(pendingId)) return;
        int amount = prefs.getInt("pending_order_total", 0);
        prefs.edit().remove("pending_order_id").remove("pending_order_total").remove("payment_processed_order_id").apply();
        cart.clear();
        checkoutInProgress = false;
        if (cartRows != null) refreshCart();
        if (checkoutButton != null) checkoutButton.setText("Checkout");
        Toast.makeText(this, "Payment confirmed for " + money(amount) + ". Printing is waiting for Brother printer integration.", Toast.LENGTH_LONG).show();
    }

    private void showCheckoutError(String message) {
        runOnUiThread(() -> {
            checkoutInProgress = false;
            checkoutButton.setEnabled(!cart.isEmpty());
            checkoutButton.setText("Checkout");
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    private static String money(int cents) {
        return String.format(Locale.US, "$%d.%02d", cents / 100, cents % 100);
    }

    private static final class MenuDrink {
        final String series;
        final String name;
        final int priceCents;
        MenuDrink(String series, String name, int priceCents) {
            this.series = series;
            this.name = name;
            this.priceCents = priceCents;
        }
    }

    private static final class Topping {
        final String name;
        final int priceCents;
        Topping(String name, int priceCents) { this.name = name; this.priceCents = priceCents; }
    }

    private static final class DrinkOrder {
        final MenuDrink drink;
        final String ice;
        final String sugar;
        final List<Topping> toppings;
        DrinkOrder(MenuDrink drink, String ice, String sugar, List<Topping> toppings) {
            this.drink = drink; this.ice = ice; this.sugar = sugar; this.toppings = new ArrayList<>(toppings);
        }
        int totalCents() {
            int total = drink.priceCents;
            for (Topping topping : toppings) total += topping.priceCents;
            return total;
        }
        List<String> printableDefaults() {
            List<String> mods = new ArrayList<>();
            if (!"Regular Ice".equals(ice)) mods.add(ice);
            if (!"Regular Sugar".equals(sugar)) mods.add(sugar);
            return mods;
        }
        String noteForClover() {
            List<String> mods = printableDefaults();
            for (Topping topping : toppings) mods.add(topping.name);
            return mods.isEmpty() ? null : String.join(", ", mods);
        }
        String summary() {
            List<String> mods = printableDefaults();
            for (Topping topping : toppings) mods.add(topping.name);
            return drink.name + (mods.isEmpty() ? "" : " — " + String.join(", ", mods));
        }
    }
}
