# The Alley Label

Android app for entering The Alley drink orders on a Clover Station/Mini. The menu is grouped into the six series shown on the supplied menu, and the search field filters drinks by name. Selecting a drink opens its ice, sugar, and topping choices. The checkout button creates a Clover order with custom line items, then opens Clover Register for payment.

## Run in Android Studio

Open this folder (the one containing `settings.gradle`) as the project, sync Gradle, and run the `app` configuration on a Clover Station/Mini. A regular phone emulator can show the ordering screen, but it cannot connect to the store's Clover account or create paid Clover orders.

The app must be installed and approved on the Clover merchant device with Clover order write access. If Clover reports a permission error, grant the app the appropriate order permissions in its Clover app configuration.

## Menu behavior

- Default cup: large, 22 oz; size is not shown as a modifier.
- Defaults: Regular Ice and Regular Sugar; these are left off the printed label/customization note.
- Non-default choices: Less Ice, No Ice, Less Sugar, Slight Sugar, No Sugar.
- Toppings are charged at the prices printed in the menu: five toppings at $0.70 and four at $0.95.
- Each cup is entered as an individual Clover line item so its name and customizations can vary.

## Printing status

Automatic label printing is not complete yet. The Clover payment broadcast receiver currently only logs order events. The Brother Android Print SDK is distributed separately by Brother; it must be added to `app/libs` before USB printing can be integrated and tested. Intended printer settings are QL-810W over USB, DK-1209 (62 × 28.9 mm landscape), with auto-cut after each label.
